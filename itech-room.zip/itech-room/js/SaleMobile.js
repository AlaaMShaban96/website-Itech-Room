
// this f for calculet totel
var a =1;
var cost=0;


function addtocart(  c ) {

cost=cost+c;
document.getElementById("t").innerHTML = a;
document.getElementById("t1").innerHTML = cost;
document.getElementById("t2").innerHTML = a;
document.getElementById("t3").innerHTML = cost;
a=a+1;
}


// this f for insert item in card
var index=0;
function myFunction( c ) {
  var x = document.createElement("label");

  x.setAttribute("id", "mySelect");
  document.body.appendChild(x);

  var z = document.createElement("option");
  z.setAttribute("value", "volvocar");
  var t = document.createTextNode(c);
  z.appendChild(t);
  document.getElementById("uuu").appendChild(z);
  document.getElementById("uuu").appendChild(t);



}
