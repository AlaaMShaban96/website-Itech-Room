var index=0;
function set() {
  var x = document.getElementById("selectof").value;
  if(x==""){
  switch (x) {
    case 'leverpool':
    document.getElementById("setname").innerHTML = "Naje Shaban Hamed ";
    document.getElementById("set").innerHTML = 30;

      break;
    case 'london':
    document.getElementById("t").innerHTML = "Alaa Mohammed Shaban";
    document.getElementById("t").innerHTML = 50;

      break;
      case 'Manchester':
      document.getElementById("t").innerHTML = "Josen alter ";
      document.getElementById("t").innerHTML = 30;

        break;


  }
}else {
  alert("Select City");
}
}
var s=true;
function getimg() {
  
  var versionType=document.getElementById('mySelect1').value;
if (this.index!=0) {
  removeDummy();
  this.index==0;
}
  if (versionType!="" ) {
this.index++;
  var x = document.createElement("IMG");
  x.setAttribute("src", "img/camera/type/"+versionType);
  x.setAttribute("id", "id");
  x.setAttribute("width", "auto");
  x.setAttribute("height", "100");
  x.setAttribute("alt", "The Pulpit Rock");
  document.getElementById("column").appendChild(x);
  this.svar = false;

}else {
  alert("select type of camera or select City");
}
}
function removeDummy() {
    var elem = document.getElementById('id');
    elem.parentNode.removeChild(elem);
    return false;
}
