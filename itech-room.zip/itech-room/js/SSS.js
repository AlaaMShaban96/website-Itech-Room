function addtocart(  c ){
var x =document.getElementById("t3");
alert(x);}
