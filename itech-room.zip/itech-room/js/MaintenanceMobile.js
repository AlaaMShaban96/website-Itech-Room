var x;
kkk =0;
var index=0;
var typeOfDevice;
var versionType;
  var s=0;
function showVersionType(){

  this.typeOfDevice = x = document.getElementById("mySelect1").value;
this.s=true;
        switch (x){
          case "Iphone":
            document.getElementById("selectOfiphone").style.display = "inline-block";
            document.getElementById("selectOfiphone2").style.display = "inline-block"

            document.getElementById("selectOfSamsung").style.display = "none";
            document.getElementById("selectOfSamsung2").style.display = "none";

            document.getElementById("selectOfHuawei").style.display = "none";
            document.getElementById("selectOfHuawei2").style.display = "none";



             break;

           case "Samsung":
             document.getElementById("selectOfSamsung").style.display = "inline-block";
             document.getElementById("selectOfSamsung2").style.display = "inline-block";

             document.getElementById("selectOfHuawei").style.display = "none";
             document.getElementById("selectOfHuawei2").style.display = "none";

             document.getElementById("selectOfiphone").style.display = "none";
             document.getElementById("selectOfiphone2").style.display = "none";

              break;

            case "Huawei" :{
               document.getElementById("selectOfHuawei").style.display = "inline-block";
               document.getElementById("selectOfHuawei2").style.display = "inline-block";

               document.getElementById("selectOfSamsung").style.display = "none";
               document.getElementById("selectOfSamsung2").style.display = "none";

               document.getElementById("selectOfiphone").style.display = "none";
               document.getElementById("selectOfiphone2").style.display = "none"
               break;
             }
           }


        }

function selectVersionTyp(){

// typeOfDevice =  document.getElementById("mySelect1").value;
switch (this.typeOfDevice) {
   case "Iphone":
          this.versionType =document.getElementById("selectOfiphone").value;

          break;
   case "Samsung":
          this.versionType =document.getElementById("selectOfSamsung").value;
          break;
   case "Huawei":
          this.versionType =document.getElementById("selectOfHuawei").value;
          break;

}

if (  this.versionType=="") {
  alert("select eny one");

}else {
  document.getElementById("problems").style.display = "inline-block";
  document.getElementById("problems2").style.display = "inline-block";


}

}

function calculator() {
var x = document.getElementById("problems").value;

switch (x) {
  case `0`:
     document.getElementById("set").innerHTML = 10;
     document.getElementById("set").style.color="red";
     break;
  case `1`:
     document.getElementById("set").innerHTML = 15;
     document.getElementById("set").style.color="red";
     break;
  case `2`:
     document.getElementById("set").innerHTML = 25;
     document.getElementById("set").style.color="red";
     break;
  case `3`:
     document.getElementById("set").innerHTML = 30;
     document.getElementById("set").style.color="red";
     break;
  case `4`:
     document.getElementById("setall").innerHTML = "cull it support";
     document.getElementById("setall").style.color="red";
     break;



}
}


function getimg() {
if (this.index!=0) {
  removeDummy();
  this.index==0;
}
  if (this.s) {
this.index++;
  var x = document.createElement("IMG");
  x.setAttribute("src", "img/phons/type/"+this.versionType);
  x.setAttribute("id", "id");
  x.setAttribute("width", "auto");
  x.setAttribute("height", "200");
  x.setAttribute("alt", "The Pulpit Rock");
  document.getElementById("column").appendChild(x);
  this.svar = false;
}
}
function removeDummy() {
    var elem = document.getElementById('id');
    elem.parentNode.removeChild(elem);
    return false;
}
